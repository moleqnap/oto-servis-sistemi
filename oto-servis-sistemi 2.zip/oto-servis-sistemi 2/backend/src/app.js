// /oto-servis-sistemi/backend/src/app.js
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const { initializeDatabase } = require('./db');
const routes = require('./routes');
const authRouter = require('./routes/authRouter');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Database initialization
async function startServer() {
    try {
        const db = await initializeDatabase();
        app.locals.db = db;
        console.log('Database initialized successfully');

        // Routes
        app.use('/api/auth', authRouter);
        app.use('/api', routes);

        // Error handling
        app.use((err, req, res, next) => {
            console.error(err.stack);
            res.status(500).json({ 
                message: 'Bir hata oluştu',
                error: process.env.NODE_ENV === 'development' ? err.message : undefined
            });
        });

        const PORT = process.env.PORT || 3000;
        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });

    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
}

startServer();

module.exports = app;
