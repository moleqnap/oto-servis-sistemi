const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const dotenv = require('dotenv');

// Routes
const musteriRoutes = require('./routes/musteriRoutes');
const aracRoutes = require('./routes/aracRoutes');
const servisRoutes = require('./routes/servisRoutes');
const stokRoutes = require('./routes/stokRoutes');
const faturaRoutes = require('./routes/faturaRoutes');
const kasaRoutes = require('./routes/kasaRoutes');
const teslimRoutes = require('./routes/teslimRoutes');
const raporRoutes = require('./routes/raporRoutes');

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Routes
app.use('/api/musteriler', musteriRoutes);
app.use('/api/araclar', aracRoutes);
app.use('/api/servis', servisRoutes);
app.use('/api/stok', stokRoutes);
app.use('/api/faturalar', faturaRoutes);
app.use('/api/kasa', kasaRoutes);
app.use('/api/teslimler', teslimRoutes);
app.use('/api/raporlar', raporRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
