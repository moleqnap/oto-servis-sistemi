// /oto-servis-sistemi/backend/src/db/index.js
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');
const fs = require('fs');

async function initializeDatabase() {
    const dbPath = path.resolve(__dirname, '../../data/otoservis.db');
    const schemaPath = path.resolve(__dirname, './schema.sql');
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }

    // Open database connection
    const db = await open({
        filename: dbPath,
        driver: sqlite3.Database
    });

    // Read and execute schema
    const schema = fs.readFileSync(schemaPath, 'utf8');
    await db.exec(schema);

    // Enable foreign keys
    await db.exec('PRAGMA foreign_keys = ON');

    return db;
}

module.exports = {
    initializeDatabase
};
