// /oto-servis-sistemi/backend/src/db/seed.js
const bcrypt = require('bcrypt');
const { initializeDatabase } = require('./index');

async function seedDatabase() {
    const db = await initializeDatabase();

    // Admin kullanıcısı oluştur
    const adminPassword = await bcrypt.hash('admin123', 10);
    await db.run(`
        INSERT INTO kullanicilar (kullanici_adi, sifre_hash, ad_soyad, rol)
        VALUES ('admin', ?, 'Sistem Yöneticisi', 'admin')
    `, [adminPassword]);

    // Örnek teknisyenler
    const teknisyenler = [
        ['Ahmet Yılmaz', 'Motor Sistemleri', '5551112233'],
        ['Mehmet Demir', 'Elektrik Sistemleri', '5551112234'],
        ['Ali Çelik', 'Mekanik Sistemler', '5551112235']
    ];

    for (const [ad_soyad, uzmanlik, telefon] of teknisyenler) {
        await db.run(`
            INSERT INTO teknisyenler (ad_soyad, uzmanlik, telefon)
            VALUES (?, ?, ?)
        `, [ad_soyad, uzmanlik, telefon]);
    }

    // Örnek stok parçaları
    const parcalar = [
        ['YG001', 'Yağ Filtresi', 50, 10, 150.00],
        ['HF001', 'Hava Filtresi', 40, 8, 120.00],
        ['BL001', 'Fren Balatası', 30, 5, 450.00],
        ['AK001', 'Akü', 15, 3, 1200.00]
    ];

    for (const [kod, ad, miktar, min_miktar, fiyat] of parcalar) {
        await db.run(`
            INSERT INTO stok (parca_kodu, parca_adi, miktar, minimum_miktar, birim_fiyat)
            VALUES (?, ?, ?, ?, ?)
        `, [kod, ad, miktar, min_miktar, fiyat]);
    }

    console.log('Örnek veriler başarıyla yüklendi.');
    process.exit(0);
}

seedDatabase().catch(error => {
    console.error('Seed işlemi başarısız:', error);
    process.exit(1);
});
