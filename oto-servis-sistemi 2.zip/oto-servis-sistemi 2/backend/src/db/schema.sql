CREATE TABLE IF NOT EXISTS kullanicilar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kullanici_adi TEXT UNIQUE NOT NULL,
    sifre_hash TEXT NOT NULL,
    ad_soyad TEXT NOT NULL,
    rol TEXT NOT NULL,
    son_giris DATETIME
);

CREATE TABLE IF NOT EXISTS musteriler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ad_soyad TEXT NOT NULL,
    telefon TEXT NOT NULL,
    email TEXT,
    adres TEXT,
    kayit_tarihi DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS araclar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    musteri_id INTEGER NOT NULL,
    plaka TEXT UNIQUE NOT NULL,
    marka TEXT NOT NULL,
    model TEXT NOT NULL,
    yil INTEGER NOT NULL,
    vin TEXT UNIQUE,
    kayit_tarihi DATETIME NOT NULL,
    FOREIGN KEY (musteri_id) REFERENCES musteriler(id)
);

CREATE TABLE IF NOT EXISTS teknisyenler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ad_soyad TEXT NOT NULL,
    uzmanlik TEXT,
    telefon TEXT,
    durum TEXT DEFAULT 'Aktif'
);

CREATE TABLE IF NOT EXISTS servis_kayitlari (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    arac_id INTEGER NOT NULL,
    teknisyen_id INTEGER NOT NULL,
    servis_detay TEXT NOT NULL,
    tahmini_sure INTEGER,
    durum TEXT NOT NULL,
    tarih DATETIME NOT NULL,
    FOREIGN KEY (arac_id) REFERENCES araclar(id),
    FOREIGN KEY (teknisyen_id) REFERENCES teknisyenler(id)
);

CREATE TABLE IF NOT EXISTS stok (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    parca_kodu TEXT UNIQUE NOT NULL,
    parca_adi TEXT NOT NULL,
    miktar INTEGER NOT NULL,
    minimum_miktar INTEGER NOT NULL,
    birim_fiyat DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS faturalar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    is_emri_id INTEGER NOT NULL,
    toplam_tutar DECIMAL(10,2) NOT NULL,
    kdv_orani INTEGER NOT NULL,
    odeme_durumu TEXT NOT NULL,
    odeme_yontemi TEXT,
    fatura_tarihi DATETIME NOT NULL,
    FOREIGN KEY (is_emri_id) REFERENCES servis_kayitlari(id)
);

CREATE TABLE IF NOT EXISTS kasa_islemleri (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tur TEXT NOT NULL,
    tutar DECIMAL(10,2) NOT NULL,
    aciklama TEXT,
    odeme_yontemi TEXT NOT NULL,
    tarih DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS teslimler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    servis_id INTEGER NOT NULL,
    teslim_alan TEXT NOT NULL,
    teslim_notu TEXT,
    kilometre INTEGER,
    teslim_tarihi DATETIME NOT NULL,
    FOREIGN KEY (servis_id) REFERENCES servis_kayitlari(id)
);
