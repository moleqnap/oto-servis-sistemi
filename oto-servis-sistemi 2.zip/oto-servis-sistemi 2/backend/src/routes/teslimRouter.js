// /oto-servis-sistemi/backend/src/routes/teslimRouter.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  const db = req.app.locals.db;
  const teslimler = await db.all(`
    SELECT 
      t.*,
      a.plaka as arac_plaka,
      a.marka as arac_marka,
      a.model as arac_model,
      m.ad_soyad as musteri_adi
    FROM teslimler t
    JOIN servis_kayitlari s ON t.servis_id = s.id
    JOIN araclar a ON s.arac_id = a.id
    JOIN musteriler m ON a.musteri_id = m.id
    ORDER BY t.teslim_tarihi DESC
  `);
  res.json(teslimler);
});

router.post('/', async (req, res) => {
  const db = req.app.locals.db;
  const { servis_id, teslim_alan, teslim_notu, kilometre } = req.body;

  // Önce servis kaydını tamamlandı olarak işaretle
  await db.run(
    'UPDATE servis_kayitlari SET durum = ? WHERE id = ?',
    ['Tamamlandı', servis_id]
  );

  // Teslim kaydını oluştur
  const result = await db.run(`
    INSERT INTO teslimler (
      servis_id, teslim_alan, teslim_notu,
      kilometre, teslim_tarihi
    ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
  `, [servis_id, teslim_alan, teslim_notu, kilometre]);

  res.status(201).json({ id: result.lastID });
});

router.get('/:id/pdf', async (req, res) => {
  const db = req.app.locals.db;
  const teslim = await db.get(`
    SELECT 
      t.*,
      a.plaka as arac_plaka,
      a.marka as arac_marka,
      a.model as arac_model,
      m.ad_soyad as musteri_adi,
      m.telefon as musteri_telefon,
      s.servis_detay
    FROM teslimler t
    JOIN servis_kayitlari s ON t.servis_id = s.id
    JOIN araclar a ON s.arac_id = a.id
    JOIN musteriler m ON a.musteri_id = m.id
    WHERE t.id = ?
  `, [req.params.id]);

  // PDF oluşturma işlemi burada yapılacak
  // Şimdilik JSON olarak dönüyoruz
  res.json(teslim);
});

module.exports = router;
