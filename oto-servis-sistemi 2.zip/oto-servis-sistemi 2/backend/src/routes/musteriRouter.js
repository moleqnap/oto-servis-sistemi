// /oto-servis-sistemi/backend/src/routes/musteriRouter.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  const db = req.app.locals.db;
  const musteriler = await db.all(`
    SELECT 
      m.*,
      COUNT(a.id) as arac_sayisi,
      COUNT(s.id) as servis_sayisi
    FROM musteriler m
    LEFT JOIN araclar a ON m.id = a.musteri_id
    LEFT JOIN servis_kayitlari s ON a.id = s.arac_id
    GROUP BY m.id
    ORDER BY m.ad_soyad ASC
  `);
  res.json(musteriler);
});

router.post('/', async (req, res) => {
  const db = req.app.locals.db;
  const { ad_soyad, telefon, email, adres } = req.body;

  const result = await db.run(`
    INSERT INTO musteriler (
      ad_soyad, telefon, email, adres, 
      kayit_tarihi
    ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
  `, [ad_soyad, telefon, email, adres]);

  res.status(201).json({ id: result.lastID });
});

router.put('/:id', async (req, res) => {
  const db = req.app.locals.db;
  const { ad_soyad, telefon, email, adres } = req.body;

  await db.run(`
    UPDATE musteriler 
    SET ad_soyad = ?, telefon = ?, email = ?, adres = ?
    WHERE id = ?
  `, [ad_soyad, telefon, email, adres, req.params.id]);

  res.json({ message: 'Müşteri güncellendi' });
});

router.get('/:id/araclar', async (req, res) => {
  const db = req.app.locals.db;
  const araclar = await db.all(`
    SELECT 
      a.*,
      COUNT(s.id) as servis_sayisi,
      MAX(s.tarih) as son_servis_tarihi
    FROM araclar a
    LEFT JOIN servis_kayitlari s ON a.id = s.arac_id
    WHERE a.musteri_id = ?
    GROUP BY a.id
  `, [req.params.id]);
  
  res.json(araclar);
});

router.get('/:id/servis-gecmisi', async (req, res) => {
  const db = req.app.locals.db;
  const servisGecmisi = await db.all(`
    SELECT 
      s.*,
      a.plaka,
      a.marka,
      a.model
    FROM servis_kayitlari s
    JOIN araclar a ON s.arac_id = a.id
    WHERE a.musteri_id = ?
    ORDER BY s.tarih DESC
  `, [req.params.id]);
  
  res.json(servisGecmisi);
});

module.exports = router;
