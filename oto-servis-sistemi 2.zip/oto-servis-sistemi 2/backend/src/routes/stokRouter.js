// /oto-servis-sistemi/backend/src/routes/stokRouter.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  const db = req.app.locals.db;
  const stoklar = await db.all(`
    SELECT * FROM stok
    ORDER BY parca_adi ASC
  `);
  res.json(stoklar);
});

router.post('/', async (req, res) => {
  const db = req.app.locals.db;
  const { parca_kodu, parca_adi, miktar, minimum_miktar, birim_fiyat } = req.body;

  const result = await db.run(`
    INSERT INTO stok (
      parca_kodu, parca_adi, miktar, 
      minimum_miktar, birim_fiyat
    ) VALUES (?, ?, ?, ?, ?)
  `, [parca_kodu, parca_adi, miktar, minimum_miktar, birim_fiyat]);

  res.status(201).json({ id: result.lastID });
});

router.patch('/:id', async (req, res) => {
  const db = req.app.locals.db;
  const { miktar } = req.body;
  
  await db.run(
    'UPDATE stok SET miktar = ? WHERE id = ?',
    [miktar, req.params.id]
  );

  res.json({ message: 'Stok güncellendi' });
});

router.get('/kritik', async (req, res) => {
  const db = req.app.locals.db;
  const kritikStoklar = await db.all(`
    SELECT * FROM stok
    WHERE miktar <= minimum_miktar
    ORDER BY miktar ASC
  `);
  res.json(kritikStoklar);
});

module.exports = router;
