// /oto-servis-sistemi/backend/src/routes/index.js
const express = require('express');
const router = express.Router();

const musteriRouter = require('./musteriRouter');
const aracRouter = require('./aracRouter');
const servisRouter = require('./servisRouter');
const stokRouter = require('./stokRouter');
const faturaRouter = require('./faturaRouter');
const kasaRouter = require('./kasaRouter');
const teslimRouter = require('./teslimRouter');

router.use('/musteriler', musteriRouter);
router.use('/araclar', aracRouter);
router.use('/servis', servisRouter);
router.use('/stok', stokRouter);
router.use('/faturalar', faturaRouter);
router.use('/kasa', kasaRouter);
router.use('/teslim', teslimRouter);

module.exports = router;
