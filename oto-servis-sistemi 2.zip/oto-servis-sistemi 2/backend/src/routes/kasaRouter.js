// /oto-servis-sistemi/backend/src/routes/kasaRouter.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/durum', async (req, res) => {
  const db = req.app.locals.db;
  
  const kasaDurum = await db.get(`
    SELECT 
      SUM(CASE WHEN tur = 'gelir' THEN tutar ELSE -tutar END) as toplam_bakiye,
      SUM(CASE WHEN tur = 'gelir' AND DATE(tarih) = DATE('now') THEN tutar ELSE 0 END) as gunluk_gelir,
      SUM(CASE WHEN tur = 'gider' AND DATE(tarih) = DATE('now') THEN tutar ELSE 0 END) as gunluk_gider
    FROM kasa_islemleri
  `);
  
  res.json(kasaDurum);
});

router.get('/islemler', async (req, res) => {
  const db = req.app.locals.db;
  const islemler = await db.all(`
    SELECT * FROM kasa_islemleri
    ORDER BY tarih DESC
    LIMIT 100
  `);
  res.json(islemler);
});

router.post('/islemler', async (req, res) => {
  const db = req.app.locals.db;
  const { tur, tutar, aciklama, odeme_yontemi } = req.body;

  const result = await db.run(`
    INSERT INTO kasa_islemleri (
      tur, tutar, aciklama, 
      odeme_yontemi, tarih
    ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
  `, [tur, tutar, aciklama, odeme_yontemi]);

  res.status(201).json({ id: result.lastID });
});

router.get('/rapor', async (req, res) => {
  const db = req.app.locals.db;
  const { baslangic, bitis } = req.query;

  const rapor = await db.all(`
    SELECT 
      DATE(tarih) as tarih,
      SUM(CASE WHEN tur = 'gelir' THEN tutar ELSE 0 END) as gelir,
      SUM(CASE WHEN tur = 'gider' THEN tutar ELSE 0 END) as gider,
      SUM(CASE WHEN tur = 'gelir' THEN tutar ELSE -tutar END) as net
    FROM kasa_islemleri
    WHERE DATE(tarih) BETWEEN ? AND ?
    GROUP BY DATE(tarih)
    ORDER BY tarih DESC
  `, [baslangic, bitis]);

  res.json(rapor);
});

module.exports = router;
