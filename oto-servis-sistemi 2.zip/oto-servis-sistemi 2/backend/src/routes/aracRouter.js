// /oto-servis-sistemi/backend/src/routes/aracRouter.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  const db = req.app.locals.db;
  const araclar = await db.all(`
    SELECT 
      a.*,
      m.ad_soyad as musteri_adi,
      COUNT(s.id) as servis_sayisi,
      MAX(s.tarih) as son_servis_tarihi
    FROM araclar a
    JOIN musteriler m ON a.musteri_id = m.id
    LEFT JOIN servis_kayitlari s ON a.id = s.arac_id
    GROUP BY a.id
    ORDER BY a.plaka ASC
  `);
  res.json(araclar);
});

router.post('/', async (req, res) => {
  const db = req.app.locals.db;
  const { musteri_id, plaka, marka, model, yil, vin } = req.body;

  const result = await db.run(`
    INSERT INTO araclar (
      musteri_id, plaka, marka, model, 
      yil, vin, kayit_tarihi
    ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
  `, [musteri_id, plaka, marka, model, yil, vin]);

  res.status(201).json({ id: result.lastID });
});

router.get('/:id/servis-gecmisi', async (req, res) => {
  const db = req.app.locals.db;
  const servisGecmisi = await db.all(`
    SELECT 
      s.*,
      t.ad_soyad as teknisyen_adi,
      f.toplam_tutar,
      f.odeme_durumu
    FROM servis_kayitlari s
    LEFT JOIN teknisyenler t ON s.teknisyen_id = t.id
    LEFT JOIN faturalar f ON s.id = f.is_emri_id
    WHERE s.arac_id = ?
    ORDER BY s.tarih DESC
  `, [req.params.id]);
  
  res.json(servisGecmisi);
});

router.put('/:id', async (req, res) => {
  const db = req.app.locals.db;
  const { plaka, marka, model, yil, vin } = req.body;

  await db.run(`
    UPDATE araclar 
    SET plaka = ?, marka = ?, model = ?, 
        yil = ?, vin = ?
    WHERE id = ?
  `, [plaka, marka, model, yil, vin, req.params.id]);

  res.json({ message: 'Araç bilgileri güncellendi' });
});

router.get('/istatistikler', async (req, res) => {
  const db = req.app.locals.db;
  const istatistikler = await db.get(`
    SELECT 
      COUNT(*) as toplam_arac,
      COUNT(DISTINCT marka) as marka_sayisi,
      AVG(yil) as ortalama_yil
    FROM araclar
  `);
  
  res.json(istatistikler);
});

module.exports = router;
