// /oto-servis-sistemi/backend/src/routes/servisRouter.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  const db = req.app.locals.db;
  const servisKayitlari = await db.all(`
    SELECT 
      s.*,
      a.plaka as arac_plaka,
      m.ad_soyad as musteri_adi,
      t.ad_soyad as teknisyen_adi
    FROM servis_kayitlari s
    JOIN araclar a ON s.arac_id = a.id
    JOIN musteriler m ON a.musteri_id = m.id
    JOIN teknisyenler t ON s.teknisyen_id = t.id
    ORDER BY s.tarih DESC
  `);
  res.json(servisKayitlari);
});

router.post('/', async (req, res) => {
  const db = req.app.locals.db;
  const { arac_id, teknisyen_id, servis_detay, tahmini_sure } = req.body;

  const result = await db.run(`
    INSERT INTO servis_kayitlari (
      arac_id, teknisyen_id, servis_detay, 
      tahmini_sure, durum, tarih
    ) VALUES (?, ?, ?, ?, 'Bekliyor', CURRENT_TIMESTAMP)
  `, [arac_id, teknisyen_id, servis_detay, tahmini_sure]);

  res.status(201).json({ id: result.lastID });
});

router.patch('/:id/durum', async (req, res) => {
  const db = req.app.locals.db;
  const { durum } = req.body;
  
  await db.run(
    'UPDATE servis_kayitlari SET durum = ? WHERE id = ?',
    [durum, req.params.id]
  );

  res.json({ message: 'Durum güncellendi' });
});

router.get('/teknisyenler', async (req, res) => {
  const db = req.app.locals.db;
  const teknisyenler = await db.all('SELECT * FROM teknisyenler');
  res.json(teknisyenler);
});

module.exports = router;
