// /oto-servis-sistemi/backend/src/routes/faturaRouter.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  const db = req.app.locals.db;
  const faturalar = await db.all(`
    SELECT 
      f.*,
      m.ad_soyad as musteri_adi,
      a.plaka as arac_plaka
    FROM faturalar f
    JOIN servis_kayitlari s ON f.is_emri_id = s.id
    JOIN araclar a ON s.arac_id = a.id
    JOIN musteriler m ON a.musteri_id = m.id
    ORDER BY f.fatura_tarihi DESC
  `);
  res.json(faturalar);
});

router.post('/', async (req, res) => {
  const db = req.app.locals.db;
  const { is_emri_id, toplam_tutar, kdv_orani, odeme_yontemi } = req.body;

  const result = await db.run(`
    INSERT INTO faturalar (
      is_emri_id, toplam_tutar, kdv_orani,
      odeme_durumu, odeme_yontemi, fatura_tarihi
    ) VALUES (?, ?, ?, 'Bekliyor', ?, CURRENT_TIMESTAMP)
  `, [is_emri_id, toplam_tutar, kdv_orani, odeme_yontemi]);

  res.status(201).json({ id: result.lastID });
});

router.patch('/:id/odeme', async (req, res) => {
  const db = req.app.locals.db;
  const { odeme_durumu } = req.body;
  
  await db.run(
    'UPDATE faturalar SET odeme_durumu = ? WHERE id = ?',
    [odeme_durumu, req.params.id]
  );

  res.json({ message: 'Ödeme durumu güncellendi' });
});

router.get('/:id/pdf', async (req, res) => {
  const db = req.app.locals.db;
  const fatura = await db.get(`
    SELECT 
      f.*,
      m.ad_soyad as musteri_adi,
      m.adres as musteri_adres,
      a.plaka as arac_plaka,
      a.marka as arac_marka,
      a.model as arac_model
    FROM faturalar f
    JOIN servis_kayitlari s ON f.is_emri_id = s.id
    JOIN araclar a ON s.arac_id = a.id
    JOIN musteriler m ON a.musteri_id = m.id
    WHERE f.id = ?
  `, [req.params.id]);

  // PDF oluşturma işlemi burada yapılacak
  // Örnek olarak fatura verilerini JSON olarak dönüyoruz
  res.json(fatura);
});

module.exports = router;
