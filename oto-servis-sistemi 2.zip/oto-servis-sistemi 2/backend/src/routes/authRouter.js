// /oto-servis-sistemi/backend/src/routes/authRouter.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

router.post('/login', async (req, res) => {
    const db = req.app.locals.db;
    const { kullanici_adi, sifre } = req.body;

    const kullanici = await db.get(
        'SELECT * FROM kullanicilar WHERE kullanici_adi = ?',
        [kullanici_adi]
    );

    if (!kullanici || !await bcrypt.compare(sifre, kullanici.sifre_hash)) {
        return res.status(401).json({ message: 'Geçersiz kullanıcı adı veya şifre' });
    }

    // Son giriş tarihini güncelle
    await db.run(
        'UPDATE kullanicilar SET son_giris = CURRENT_TIMESTAMP WHERE id = ?',
        [kullanici.id]
    );

    const token = jwt.sign(
        { 
            id: kullanici.id, 
            kullanici_adi: kullanici.kullanici_adi,
            rol: kullanici.rol 
        },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
    );

    res.json({
        token,
        kullanici: {
            id: kullanici.id,
            kullanici_adi: kullanici.kullanici_adi,
            ad_soyad: kullanici.ad_soyad,
            rol: kullanici.rol
        }
    });
});

router.post('/register', async (req, res) => {
    const db = req.app.locals.db;
    const { kullanici_adi, sifre, ad_soyad, rol } = req.body;

    const mevcutKullanici = await db.get(
        'SELECT id FROM kullanicilar WHERE kullanici_adi = ?',
        [kullanici_adi]
    );

    if (mevcutKullanici) {
        return res.status(400).json({ message: 'Bu kullanıcı adı zaten kullanılıyor' });
    }

    const sifre_hash = await bcrypt.hash(sifre, 10);

    const result = await db.run(`
        INSERT INTO kullanicilar (
            kullanici_adi, sifre_hash, ad_soyad, 
            rol, son_giris
        ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
    `, [kullanici_adi, sifre_hash, ad_soyad, rol]);

    res.status(201).json({ 
        message: 'Kullanıcı başarıyla oluşturuldu',
        id: result.lastID 
    });
});

router.get('/me', async (req, res) => {
    const db = req.app.locals.db;
    const kullanici = await db.get(
        'SELECT id, kullanici_adi, ad_soyad, rol FROM kullanicilar WHERE id = ?',
        [req.user.id]
    );
    
    res.json(kullanici);
});

module.exports = router;
