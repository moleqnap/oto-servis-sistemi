// /oto-servis-sistemi/backend/src/config/env.js
require('dotenv').config();

const config = {
    port: process.env.PORT || 3000,
    jwtSecret: process.env.JWT_SECRET || 'your-secret-key',
    nodeEnv: process.env.NODE_ENV || 'development',
    dbPath: process.env.DB_PATH || 'data/otoservis.db',
    corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:5173',
    saltRounds: parseInt(process.env.SALT_ROUNDS) || 10,
    tokenExpiration: process.env.TOKEN_EXPIRATION || '24h'
};

// Validate required environment variables
const requiredEnvVars = ['JWT_SECRET'];
const missingEnvVars = requiredEnvVars.filter(envVar => !process.env[envVar]);

if (missingEnvVars.length > 0) {
    throw new Error(`Missing required environment variables: ${missingEnvVars.join(', ')}`);
}

module.exports = config;
