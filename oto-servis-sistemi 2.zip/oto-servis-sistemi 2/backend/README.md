# Oto Servis Yönetim Sistemi - Backend

## Proje Hakkında
Bu proje, otomotiv servislerinin müşteri, araç, servis, stok ve fatura yönetimini sağlayan bir sistemin backend uygulamasıdır.

## Teknolojiler
- Node.js
- Express.js
- SQLite
- JWT Authentication

## Kurulum

1. Bağımlılıkları yükleyin:
```bash
npm install
