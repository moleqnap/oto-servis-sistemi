import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import Sidebar from './components/layout/Sidebar';
import Dashboard from './pages/Dashboard';
import MusteriYonetimi from './pages/MusteriYonetimi';
import AracYonetimi from './pages/AracYonetimi';
import ServisYonetimi from './pages/ServisYonetimi';
import StokYonetimi from './pages/StokYonetimi';
import FaturaYonetimi from './pages/FaturaYonetimi';
import KasaYonetimi from './pages/KasaYonetimi';
import TeslimYonetimi from './pages/TeslimYonetimi';
import RaporlamaYonetimi from './pages/RaporlamaYonetimi';

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="flex h-screen bg-gray-100">
          <Sidebar />
          <div className="flex-1 overflow-auto p-8">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/musteriler" element={<MusteriYonetimi />} />
              <Route path="/araclar" element={<AracYonetimi />} />
              <Route path="/servisler" element={<ServisYonetimi />} />
              <Route path="/stok" element={<StokYonetimi />} />
              <Route path="/faturalar" element={<FaturaYonetimi />} />
              <Route path="/kasa" element={<KasaYonetimi />} />
              <Route path="/teslimler" element={<TeslimYonetimi />} />
              <Route path="/raporlar" element={<RaporlamaYonetimi />} />
            </Routes>
          </div>
        </div>
      </Router>
    </QueryClientProvider>
  );
};

export default App;
