// /oto-servis-sistemi/frontend/src/pages/RaporlamaYonetimi.jsx
import React, { useState } from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';

const RaporlamaYonetimi = () => {
  const [dateRange, setDateRange] = useState({
    start_date: '',
    end_date: ''
  });

  const { data: raporlar, isLoading } = useQuery(
    ['raporlar', dateRange],
    async () => {
      const { data } = await axios.get('/api/raporlar', { params: dateRange });
      return data;
    }
  );

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Raporlama</h1>
        <div className="flex space-x-4">
          <input
            type="date"
            className="input"
            value={dateRange.start_date}
            onChange={(e) => setDateRange({...dateRange, start_date: e.target.value})}
          />
          <input
            type="date"
            className="input"
            value={dateRange.end_date}
            onChange={(e) => setDateRange({...dateRange, end_date: e.target.value})}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-700">Toplam Gelir</h3>
          <p className="text-3xl font-bold text-green-600">₺{raporlar?.toplam_gelir}</p>
        </div>
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-700">Toplam Gider</h3>
          <p className="text-3xl font-bold text-red-600">₺{raporlar?.toplam_gider}</p>
        </div>
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-700">Net Kar</h3>
          <p className="text-3xl font-bold text-blue-600">₺{raporlar?.net_kar}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-semibold">Servis İstatistikleri</h3>
          </div>
          <div className="card-body">
            <div className="space-y-4">
              <div className="flex justify-between">
                <span>Toplam Servis Sayısı:</span>
                <span className="font-semibold">{raporlar?.servis_istatistikleri.toplam}</span>
              </div>
              <div className="flex justify-between">
                <span>Tamamlanan Servisler:</span>
                <span className="font-semibold">{raporlar?.servis_istatistikleri.tamamlanan}</span>
              </div>
              <div className="flex justify-between">
                <span>Bekleyen Servisler:</span>
                <span className="font-semibold">{raporlar?.servis_istatistikleri.bekleyen}</span>
              </div>
              <div className="flex justify-between">
                <span>Ortalama Servis Süresi:</span>
                <span className="font-semibold">{raporlar?.servis_istatistikleri.ortalama_sure} saat</span>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-semibold">Müşteri İstatistikleri</h3>
          </div>
          <div className="card-body">
            <div className="space-y-4">
              <div className="flex justify-between">
                <span>Toplam Müşteri Sayısı:</span>
                <span className="font-semibold">{raporlar?.musteri_istatistikleri.toplam}</span>
              </div>
              <div className="flex justify-between">
                <span>Yeni Müşteriler:</span>
                <span className="font-semibold">{raporlar?.musteri_istatistikleri.yeni}</span>
              </div>
              <div className="flex justify-between">
                <span>Tekrar Eden Müşteriler:</span>
                <span className="font-semibold">{raporlar?.musteri_istatistikleri.tekrar_eden}</span>
              </div>
              <div className="flex justify-between">
                <span>Ortalama Müşteri Değeri:</span>
                <span className="font-semibold">₺{raporlar?.musteri_istatistikleri.ortalama_deger}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-semibold">En Çok Yapılan Servisler</h3>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>Servis Türü</th>
              <th>Toplam Sayı</th>
              <th>Toplam Gelir</th>
            </tr>
          </thead>
          <tbody>
            {raporlar?.populer_servisler.map((servis, index) => (
              <tr key={index}>
                <td>{servis.tur}</td>
                <td>{servis.sayi}</td>
                <td>₺{servis.gelir}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-semibold">Stok Durumu</h3>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>Parça Kodu</th>
              <th>Parça Adı</th>
              <th>Mevcut Stok</th>
              <th>Minimum Stok</th>
              <th>Durum</th>
            </tr>
          </thead>
          <tbody>
            {raporlar?.stok_durumu.map((stok, index) => (
              <tr key={index}>
                <td>{stok.parca_kodu}</td>
                <td>{stok.parca_adi}</td>
                <td>{stok.mevcut_stok}</td>
                <td>{stok.minimum_stok}</td>
                <td>
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    stok.mevcut_stok <= stok.minimum_stok 
                      ? 'bg-red-100 text-red-800' 
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {stok.mevcut_stok <= stok.minimum_stok ? 'Kritik' : 'Normal'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RaporlamaYonetimi;
