// /oto-servis-sistemi/frontend/src/pages/TeslimYonetimi.jsx
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

const TeslimYonetimi = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [selectedDelivery, setSelectedDelivery] = useState(null);
  const [formData, setFormData] = useState({
    servis_id: '',
    teslim_alan: '',
    notlar: ''
  });

  const { data: teslimler, isLoading } = useQuery('teslimler', async () => {
    const { data } = await axios.get('/api/teslimler');
    return data;
  });

  const { data: servisler } = useQuery('servisler', async () => {
    const { data } = await axios.get('/api/servis');
    return data.filter(servis => 
      servis.durum === 'Tamamlandı' && !servis.teslim_edildi
    );
  });

  const createMutation = useMutation(
    (newDelivery) => axios.post('/api/teslimler', newDelivery),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('teslimler');
        queryClient.invalidateQueries('servisler');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const resetForm = () => {
    setFormData({
      servis_id: '',
      teslim_alan: '',
      notlar: ''
    });
    setSelectedDelivery(null);
  };

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Araç Teslim Yönetimi</h1>
        <button
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          Yeni Teslim
        </button>
      </div>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Tarih</th>
              <th>Araç</th>
              <th>Müşteri</th>
              <th>Teslim Alan</th>
              <th>Servis Detayı</th>
              <th>Notlar</th>
            </tr>
          </thead>
          <tbody>
            {teslimler?.map((teslim) => (
              <tr key={teslim.id}>
                <td>{new Date(teslim.tarih).toLocaleDateString('tr-TR')}</td>
                <td>{teslim.arac_plaka}</td>
                <td>{teslim.musteri_adi}</td>
                <td>{teslim.teslim_alan}</td>
                <td>{teslim.servis_detay}</td>
                <td>{teslim.notlar}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Yeni Araç Teslimi</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Servis
                </label>
                <select
                  className="input"
                  value={formData.servis_id}
                  onChange={(e) => setFormData({...formData, servis_id: e.target.value})}
                  required
                >
                  <option value="">Servis Seçin</option>
                  {servisler?.map((servis) => (
                    <option key={servis.id} value={servis.id}>
                      {servis.arac_plaka} - {servis.musteri_adi} - {servis.servis_detay}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Teslim Alan
                </label>
                <input
                  type="text"
                  className="input"
                  value={formData.teslim_alan}
                  onChange={(e) => setFormData({...formData, teslim_alan: e.target.value})}
                  required
                  placeholder="Teslim alan kişinin adı"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Notlar
                </label>
                <textarea
                  className="input"
                  value={formData.notlar}
                  onChange={(e) => setFormData({...formData, notlar: e.target.value})}
                  placeholder="Varsa ekstra notlar"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="btn-secondary"
                >
                  İptal
                </button>
                <button type="submit" className="btn-primary">
                  Teslim Et
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeslimYonetimi;
