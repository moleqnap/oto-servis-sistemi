// /oto-servis-sistemi/frontend/src/pages/StokYonetimi.jsx
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

const StokYonetimi = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [formData, setFormData] = useState({
    parca_kodu: '',
    parca_adi: '',
    miktar: '',
    minimum_miktar: '',
    birim_fiyat: ''
  });

  const { data: stoklar, isLoading } = useQuery('stoklar', async () => {
    const { data } = await axios.get('/api/stok');
    return data;
  });

  const createMutation = useMutation(
    (newItem) => axios.post('/api/stok', newItem),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('stoklar');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const updateMutation = useMutation(
    (item) => axios.put(`/api/stok/${item.id}`, item),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('stoklar');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedItem) {
      updateMutation.mutate({ ...formData, id: selectedItem.id });
    } else {
      createMutation.mutate(formData);
    }
  };

  const resetForm = () => {
    setFormData({
      parca_kodu: '',
      parca_adi: '',
      miktar: '',
      minimum_miktar: '',
      birim_fiyat: ''
    });
    setSelectedItem(null);
  };

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Stok Yönetimi</h1>
        <button
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          Yeni Parça Ekle
        </button>
      </div>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Parça Kodu</th>
              <th>Parça Adı</th>
              <th>Miktar</th>
              <th>Minimum Miktar</th>
              <th>Birim Fiyat</th>
              <th>Durum</th>
              <th>İşlemler</th>
            </tr>
          </thead>
          <tbody>
            {stoklar?.map((stok) => (
              <tr key={stok.id}>
                <td>{stok.parca_kodu}</td>
                <td>{stok.parca_adi}</td>
                <td>{stok.miktar}</td>
                <td>{stok.minimum_miktar}</td>
                <td>₺{stok.birim_fiyat}</td>
                <td>
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    stok.miktar <= stok.minimum_miktar 
                      ? 'bg-red-100 text-red-800' 
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {stok.miktar <= stok.minimum_miktar ? 'Kritik Stok' : 'Normal'}
                  </span>
                </td>
                <td>
                  <button
                    onClick={() => {
                      setSelectedItem(stok);
                      setFormData({
                        parca_kodu: stok.parca_kodu,
                        parca_adi: stok.parca_adi,
                        miktar: stok.miktar,
                        minimum_miktar: stok.minimum_miktar,
                        birim_fiyat: stok.birim_fiyat
                      });
                      setShowModal(true);
                    }}
                    className="btn-secondary mr-2"
                  >
                    Düzenle
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">
              {selectedItem ? 'Parça Düzenle' : 'Yeni Parça Ekle'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Parça Kodu
                </label>
                <input
                  type="text"
                  className="input"
                  value={formData.parca_kodu}
                  onChange={(e) => setFormData({...formData, parca_kodu: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Parça Adı
                </label>
                <input
                  type="text"
                  className="input"
                  value={formData.parca_adi}
                  onChange={(e) => setFormData({...formData, parca_adi: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Miktar
                </label>
                <input
                  type="number"
                  className="input"
                  value={formData.miktar}
                  onChange={(e) => setFormData({...formData, miktar: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Minimum Miktar
                </label>
                <input
                  type="number"
                  className="input"
                  value={formData.minimum_miktar}
                  onChange={(e) => setFormData({...formData, minimum_miktar: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Birim Fiyat (₺)
                </label>
                <input
                  type="number"
                  step="0.01"
                  className="input"
                  value={formData.birim_fiyat}
                  onChange={(e) => setFormData({...formData, birim_fiyat: e.target.value})}
                  required
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="btn-secondary"
                >
                  İptal
                </button>
                <button type="submit" className="btn-primary">
                  {selectedItem ? 'Güncelle' : 'Kaydet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StokYonetimi;
