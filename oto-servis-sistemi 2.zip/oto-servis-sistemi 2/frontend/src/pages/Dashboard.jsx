// /oto-servis-sistemi/frontend/src/pages/Dashboard.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = () => {
  const [stats, setStats] = useState({
    aktif_servisler: 0,
    bekleyen_araclar: 0,
    gunluk_ciro: 0,
    kritik_stoklar: 0
  });

  const [sonIslemler, setSonIslemler] = useState([]);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    const [statsResponse, islemlerResponse] = await Promise.all([
      axios.get('/api/dashboard/stats'),
      axios.get('/api/dashboard/son-islemler')
    ]);

    setStats(statsResponse.data);
    setSonIslemler(islemlerResponse.data);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>

      {/* İstatistik Kartları */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700">Aktif Servisler</h3>
          <p className="text-3xl font-bold text-blue-600">{stats.aktif_servisler}</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700">Bekleyen Araçlar</h3>
          <p className="text-3xl font-bold text-yellow-600">{stats.bekleyen_araclar}</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700">Günlük Ciro</h3>
          <p className="text-3xl font-bold text-green-600">₺{stats.gunluk_ciro}</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700">Kritik Stoklar</h3>
          <p className="text-3xl font-bold text-red-600">{stats.kritik_stoklar}</p>
        </div>
      </div>

      {/* Son İşlemler Tablosu */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b">
          <h2 className="text-xl font-semibold">Son İşlemler</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr>
                <th className="px-6 py-3 border-b">Tarih</th>
                <th className="px-6 py-3 border-b">İşlem</th>
                <th className="px-6 py-3 border-b">Müşteri</th>
                <th className="px-6 py-3 border-b">Araç</th>
                <th className="px-6 py-3 border-b">Tutar</th>
              </tr>
            </thead>
            <tbody>
              {sonIslemler.map((islem) => (
                <tr key={islem.id}>
                  <td className="px-6 py-4 border-b">
                    {new Date(islem.tarih).toLocaleDateString('tr-TR')}
                  </td>
                  <td className="px-6 py-4 border-b">{islem.islem_tipi}</td>
                  <td className="px-6 py-4 border-b">{islem.musteri_adi}</td>
                  <td className="px-6 py-4 border-b">{islem.arac_plaka}</td>
                  <td className="px-6 py-4 border-b">₺{islem.tutar}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
