// /oto-servis-sistemi/frontend/src/pages/MusteriYonetimi.jsx
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

const MusteriYonetimi = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [formData, setFormData] = useState({
    ad_soyad: '',
    telefon: '',
    email: '',
    adres: ''
  });

  const { data: musteriler, isLoading } = useQuery('musteriler', async () => {
    const { data } = await axios.get('/api/musteriler');
    return data;
  });

  const createMutation = useMutation(
    (newCustomer) => axios.post('/api/musteriler', newCustomer),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('musteriler');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const updateMutation = useMutation(
    (customer) => axios.put(`/api/musteriler/${customer.id}`, customer),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('musteriler');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedCustomer) {
      updateMutation.mutate({ ...formData, id: selectedCustomer.id });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (customer) => {
    setSelectedCustomer(customer);
    setFormData({
      ad_soyad: customer.ad_soyad,
      telefon: customer.telefon,
      email: customer.email,
      adres: customer.adres
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      ad_soyad: '',
      telefon: '',
      email: '',
      adres: ''
    });
    setSelectedCustomer(null);
  };

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Müşteri Yönetimi</h1>
        <button
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          Yeni Müşteri Ekle
        </button>
      </div>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Ad Soyad</th>
              <th>Telefon</th>
              <th>Email</th>
              <th>Araç Sayısı</th>
              <th>İşlemler</th>
            </tr>
          </thead>
          <tbody>
            {musteriler?.map((musteri) => (
              <tr key={musteri.id}>
                <td>{musteri.ad_soyad}</td>
                <td>{musteri.telefon}</td>
                <td>{musteri.email}</td>
                <td>{musteri.arac_sayisi}</td>
                <td>
                  <button
                    onClick={() => handleEdit(musteri)}
                    className="btn-secondary mr-2"
                  >
                    Düzenle
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">
              {selectedCustomer ? 'Müşteri Düzenle' : 'Yeni Müşteri Ekle'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Ad Soyad
                </label>
                <input
                  type="text"
                  className="input"
                  value={formData.ad_soyad}
                  onChange={(e) => setFormData({...formData, ad_soyad: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Telefon
                </label>
                <input
                  type="tel"
                  className="input"
                  value={formData.telefon}
                  onChange={(e) => setFormData({...formData, telefon: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <input
                  type="email"
                  className="input"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Adres
                </label>
                <textarea
                  className="input"
                  value={formData.adres}
                  onChange={(e) => setFormData({...formData, adres: e.target.value})}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="btn-secondary"
                >
                  İptal
                </button>
                <button type="submit" className="btn-primary">
                  {selectedCustomer ? 'Güncelle' : 'Kaydet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MusteriYonetimi;
