// /oto-servis-sistemi/frontend/src/pages/AracYonetimi.jsx
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

const AracYonetimi = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [formData, setFormData] = useState({
    musteri_id: '',
    plaka: '',
    marka: '',
    model: '',
    yil: '',
    vin: ''
  });

  const { data: araclar, isLoading } = useQuery('araclar', async () => {
    const { data } = await axios.get('/api/araclar');
    return data;
  });

  const { data: musteriler } = useQuery('musteriler', async () => {
    const { data } = await axios.get('/api/musteriler');
    return data;
  });

  const createMutation = useMutation(
    (newVehicle) => axios.post('/api/araclar', newVehicle),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('araclar');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const updateMutation = useMutation(
    (vehicle) => axios.put(`/api/araclar/${vehicle.id}`, vehicle),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('araclar');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedVehicle) {
      updateMutation.mutate({ ...formData, id: selectedVehicle.id });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (vehicle) => {
    setSelectedVehicle(vehicle);
    setFormData({
      musteri_id: vehicle.musteri_id,
      plaka: vehicle.plaka,
      marka: vehicle.marka,
      model: vehicle.model,
      yil: vehicle.yil,
      vin: vehicle.vin
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      musteri_id: '',
      plaka: '',
      marka: '',
      model: '',
      yil: '',
      vin: ''
    });
    setSelectedVehicle(null);
  };

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Araç Yönetimi</h1>
        <button
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          Yeni Araç Ekle
        </button>
      </div>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Plaka</th>
              <th>Marka</th>
              <th>Model</th>
              <th>Yıl</th>
              <th>Müşteri</th>
              <th>İşlemler</th>
            </tr>
          </thead>
          <tbody>
            {araclar?.map((arac) => (
              <tr key={arac.id}>
                <td>{arac.plaka}</td>
                <td>{arac.marka}</td>
                <td>{arac.model}</td>
                <td>{arac.yil}</td>
                <td>{arac.musteri_adi}</td>
                <td>
                  <button
                    onClick={() => handleEdit(arac)}
                    className="btn-secondary mr-2"
                  >
                    Düzenle
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">
              {selectedVehicle ? 'Araç Düzenle' : 'Yeni Araç Ekle'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Müşteri
                </label>
                <select
                  className="input"
                  value={formData.musteri_id}
                  onChange={(e) => setFormData({...formData, musteri_id: e.target.value})}
                  required
                >
                  <option value="">Müşteri Seçin</option>
                  {musteriler?.map((musteri) => (
                    <option key={musteri.id} value={musteri.id}>
                      {musteri.ad_soyad}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Plaka
                </label>
                <input
                  type="text"
                  className="input"
                  value={formData.plaka}
                  onChange={(e) => setFormData({...formData, plaka: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Marka
                </label>
                <input
                  type="text"
                  className="input"
                  value={formData.marka}
                  onChange={(e) => setFormData({...formData, marka: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Model
                </label>
                <input
                  type="text"
                  className="input"
                  value={formData.model}
                  onChange={(e) => setFormData({...formData, model: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Yıl
                </label>
                <input
                  type="number"
                  className="input"
                  value={formData.yil}
                  onChange={(e) => setFormData({...formData, yil: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  VIN
                </label>
                <input
                  type="text"
                  className="input"
                  value={formData.vin}
                  onChange={(e) => setFormData({...formData, vin: e.target.value})}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="btn-secondary"
                >
                  İptal
                </button>
                <button type="submit" className="btn-primary">
                  {selectedVehicle ? 'Güncelle' : 'Kaydet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AracYonetimi;
