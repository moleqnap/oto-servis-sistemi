// /oto-servis-sistemi/frontend/src/pages/FaturaYonetimi.jsx
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

const FaturaYonetimi = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [formData, setFormData] = useState({
    servis_id: '',
    tutar: '',
    odeme_durumu: 'Bekliyor',
    odeme_tipi: 'Nakit'
  });

  const { data: faturalar, isLoading } = useQuery('faturalar', async () => {
    const { data } = await axios.get('/api/faturalar');
    return data;
  });

  const { data: servisler } = useQuery('servisler', async () => {
    const { data } = await axios.get('/api/servis');
    return data.filter(servis => servis.durum === 'Tamamlandı');
  });

  const createMutation = useMutation(
    (newInvoice) => axios.post('/api/faturalar', newInvoice),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('faturalar');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const updateMutation = useMutation(
    (invoice) => axios.put(`/api/faturalar/${invoice.id}`, invoice),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('faturalar');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedInvoice) {
      updateMutation.mutate({ ...formData, id: selectedInvoice.id });
    } else {
      createMutation.mutate(formData);
    }
  };

  const resetForm = () => {
    setFormData({
      servis_id: '',
      tutar: '',
      odeme_durumu: 'Bekliyor',
      odeme_tipi: 'Nakit'
    });
    setSelectedInvoice(null);
  };

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Fatura Yönetimi</h1>
        <button
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          Yeni Fatura Oluştur
        </button>
      </div>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Fatura No</th>
              <th>Müşteri</th>
              <th>Araç</th>
              <th>Tutar</th>
              <th>Ödeme Durumu</th>
              <th>Ödeme Tipi</th>
              <th>Tarih</th>
              <th>İşlemler</th>
            </tr>
          </thead>
          <tbody>
            {faturalar?.map((fatura) => (
              <tr key={fatura.id}>
                <td>{fatura.fatura_no}</td>
                <td>{fatura.musteri_adi}</td>
                <td>{fatura.arac_plaka}</td>
                <td>₺{fatura.tutar}</td>
                <td>
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    fatura.odeme_durumu === 'Ödendi' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {fatura.odeme_durumu}
                  </span>
                </td>
                <td>{fatura.odeme_tipi}</td>
                <td>{new Date(fatura.tarih).toLocaleDateString('tr-TR')}</td>
                <td>
                  <button
                    onClick={() => {
                      setSelectedInvoice(fatura);
                      setFormData({
                        servis_id: fatura.servis_id,
                        tutar: fatura.tutar,
                        odeme_durumu: fatura.odeme_durumu,
                        odeme_tipi: fatura.odeme_tipi
                      });
                      setShowModal(true);
                    }}
                    className="btn-secondary mr-2"
                  >
                    Düzenle
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">
              {selectedInvoice ? 'Fatura Düzenle' : 'Yeni Fatura Oluştur'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Servis
                </label>
                <select
                  className="input"
                  value={formData.servis_id}
                  onChange={(e) => setFormData({...formData, servis_id: e.target.value})}
                  required
                >
                  <option value="">Servis Seçin</option>
                  {servisler?.map((servis) => (
                    <option key={servis.id} value={servis.id}>
                      {servis.arac_plaka} - {servis.servis_detay}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Tutar (₺)
                </label>
                <input
                  type="number"
                  step="0.01"
                  className="input"
                  value={formData.tutar}
                  onChange={(e) => setFormData({...formData, tutar: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Ödeme Durumu
                </label>
                <select
                  className="input"
                  value={formData.odeme_durumu}
                  onChange={(e) => setFormData({...formData, odeme_durumu: e.target.value})}
                  required
                >
                  <option value="Bekliyor">Bekliyor</option>
                  <option value="Ödendi">Ödendi</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Ödeme Tipi
                </label>
                <select
                  className="input"
                  value={formData.odeme_tipi}
                  onChange={(e) => setFormData({...formData, odeme_tipi: e.target.value})}
                  required
                >
                  <option value="Nakit">Nakit</option>
                  <option value="Kredi Kartı">Kredi Kartı</option>
                  <option value="Havale/EFT">Havale/EFT</option>
                </select>
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="btn-secondary"
                >
                  İptal
                </button>
                <button type="submit" className="btn-primary">
                  {selectedInvoice ? 'Güncelle' : 'Kaydet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default FaturaYonetimi;
