// /oto-servis-sistemi/frontend/src/pages/KasaYonetimi.jsx
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

const KasaYonetimi = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    islem_tipi: 'Gelir',
    tutar: '',
    aciklama: '',
    odeme_tipi: 'Nakit'
  });

  const { data: kasaHareketleri, isLoading } = useQuery('kasa', async () => {
    const { data } = await axios.get('/api/kasa');
    return data;
  });

  const { data: kasaDurumu } = useQuery('kasa-durumu', async () => {
    const { data } = await axios.get('/api/kasa/durum');
    return data;
  });

  const createMutation = useMutation(
    (newTransaction) => axios.post('/api/kasa', newTransaction),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('kasa');
        queryClient.invalidateQueries('kasa-durumu');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const resetForm = () => {
    setFormData({
      islem_tipi: 'Gelir',
      tutar: '',
      aciklama: '',
      odeme_tipi: 'Nakit'
    });
  };

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Kasa Yönetimi</h1>
        <button
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          Yeni İşlem
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-700">Kasa Durumu</h3>
          <p className="text-3xl font-bold text-green-600">₺{kasaDurumu?.bakiye}</p>
        </div>
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-700">Günlük Gelir</h3>
          <p className="text-3xl font-bold text-blue-600">₺{kasaDurumu?.gunluk_gelir}</p>
        </div>
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-700">Günlük Gider</h3>
          <p className="text-3xl font-bold text-red-600">₺{kasaDurumu?.gunluk_gider}</p>
        </div>
      </div>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Tarih</th>
              <th>İşlem Tipi</th>
              <th>Tutar</th>
              <th>Ödeme Tipi</th>
              <th>Açıklama</th>
            </tr>
          </thead>
          <tbody>
            {kasaHareketleri?.map((hareket) => (
              <tr key={hareket.id}>
                <td>{new Date(hareket.tarih).toLocaleDateString('tr-TR')}</td>
                <td>
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    hareket.islem_tipi === 'Gelir' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {hareket.islem_tipi}
                  </span>
                </td>
                <td>₺{hareket.tutar}</td>
                <td>{hareket.odeme_tipi}</td>
                <td>{hareket.aciklama}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Yeni Kasa İşlemi</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  İşlem Tipi
                </label>
                <select
                  className="input"
                  value={formData.islem_tipi}
                  onChange={(e) => setFormData({...formData, islem_tipi: e.target.value})}
                  required
                >
                  <option value="Gelir">Gelir</option>
                  <option value="Gider">Gider</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Tutar (₺)
                </label>
                <input
                  type="number"
                  step="0.01"
                  className="input"
                  value={formData.tutar}
                  onChange={(e) => setFormData({...formData, tutar: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Ödeme Tipi
                </label>
                <select
                  className="input"
                  value={formData.odeme_tipi}
                  onChange={(e) => setFormData({...formData, odeme_tipi: e.target.value})}
                  required
                >
                  <option value="Nakit">Nakit</option>
                  <option value="Kredi Kartı">Kredi Kartı</option>
                  <option value="Havale/EFT">Havale/EFT</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Açıklama
                </label>
                <textarea
                  className="input"
                  value={formData.aciklama}
                  onChange={(e) => setFormData({...formData, aciklama: e.target.value})}
                  required
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="btn-secondary"
                >
                  İptal
                </button>
                <button type="submit" className="btn-primary">
                  Kaydet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default KasaYonetimi;
