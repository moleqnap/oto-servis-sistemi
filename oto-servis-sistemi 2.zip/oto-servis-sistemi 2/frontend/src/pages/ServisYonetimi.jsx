// /oto-servis-sistemi/frontend/src/pages/ServisYonetimi.jsx
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

const ServisYonetimi = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [selectedService, setSelectedService] = useState(null);
  const [formData, setFormData] = useState({
    arac_id: '',
    teknisyen_id: '',
    servis_detay: '',
    tahmini_sure: '',
    durum: 'Bekliyor'
  });

  const { data: servisler, isLoading } = useQuery('servisler', async () => {
    const { data } = await axios.get('/api/servis');
    return data;
  });

  const { data: araclar } = useQuery('araclar', async () => {
    const { data } = await axios.get('/api/araclar');
    return data;
  });

  const { data: teknisyenler } = useQuery('teknisyenler', async () => {
    const { data } = await axios.get('/api/teknisyenler');
    return data;
  });

  const createMutation = useMutation(
    (newService) => axios.post('/api/servis', newService),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('servisler');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const updateMutation = useMutation(
    (service) => axios.put(`/api/servis/${service.id}`, service),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('servisler');
        setShowModal(false);
        resetForm();
      }
    }
  );

  const updateStatusMutation = useMutation(
    ({ id, durum }) => axios.patch(`/api/servis/${id}/durum`, { durum }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('servisler');
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedService) {
      updateMutation.mutate({ ...formData, id: selectedService.id });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleStatusChange = (id, durum) => {
    updateStatusMutation.mutate({ id, durum });
  };

  const resetForm = () => {
    setFormData({
      arac_id: '',
      teknisyen_id: '',
      servis_detay: '',
      tahmini_sure: '',
      durum: 'Bekliyor'
    });
    setSelectedService(null);
  };

  if (isLoading) {
    return <div>Yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Servis Yönetimi</h1>
        <button
          onClick={() => setShowModal(true)}
          className="btn-primary"
        >
          Yeni Servis Kaydı
        </button>
      </div>

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Araç</th>
              <th>Teknisyen</th>
              <th>Detay</th>
              <th>Durum</th>
              <th>Tahmini Süre</th>
              <th>İşlemler</th>
            </tr>
          </thead>
          <tbody>
            {servisler?.map((servis) => (
              <tr key={servis.id}>
                <td>{servis.arac_plaka}</td>
                <td>{servis.teknisyen_adi}</td>
                <td>{servis.servis_detay}</td>
                <td>
                  <select
                    value={servis.durum}
                    onChange={(e) => handleStatusChange(servis.id, e.target.value)}
                    className="input"
                  >
                    <option value="Bekliyor">Bekliyor</option>
                    <option value="İşlemde">İşlemde</option>
                    <option value="Tamamlandı">Tamamlandı</option>
                    <option value="İptal">İptal</option>
                  </select>
                </td>
                <td>{servis.tahmini_sure} saat</td>
                <td>
                  <button
                    onClick={() => {
                      setSelectedService(servis);
                      setFormData({
                        arac_id: servis.arac_id,
                        teknisyen_id: servis.teknisyen_id,
                        servis_detay: servis.servis_detay,
                        tahmini_sure: servis.tahmini_sure,
                        durum: servis.durum
                      });
                      setShowModal(true);
                    }}
                    className="btn-secondary mr-2"
                  >
                    Düzenle
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">
              {selectedService ? 'Servis Kaydı Düzenle' : 'Yeni Servis Kaydı'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Araç
                </label>
                <select
                  className="input"
                  value={formData.arac_id}
                  onChange={(e) => setFormData({...formData, arac_id: e.target.value})}
                  required
                >
                  <option value="">Araç Seçin</option>
                  {araclar?.map((arac) => (
                    <option key={arac.id} value={arac.id}>
                      {arac.plaka} - {arac.marka} {arac.model}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Teknisyen
                </label>
                <select
                  className="input"
                  value={formData.teknisyen_id}
                  onChange={(e) => setFormData({...formData, teknisyen_id: e.target.value})}
                  required
                >
                  <option value="">Teknisyen Seçin</option>
                  {teknisyenler?.map((teknisyen) => (
                    <option key={teknisyen.id} value={teknisyen.id}>
                      {teknisyen.ad_soyad}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Servis Detayı
                </label>
                <textarea
                  className="input"
                  value={formData.servis_detay}
                  onChange={(e) => setFormData({...formData, servis_detay: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Tahmini Süre (Saat)
                </label>
                <input
                  type="number"
                  className="input"
                  value={formData.tahmini_sure}
                  onChange={(e) => setFormData({...formData, tahmini_sure: e.target.value})}
                  required
                />
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="btn-secondary"
                >
                  İptal
                </button>
                <button type="submit" className="btn-primary">
                  {selectedService ? 'Güncelle' : 'Kaydet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServisYonetimi;
