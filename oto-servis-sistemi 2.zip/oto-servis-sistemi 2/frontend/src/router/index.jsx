// /oto-servis-sistemi/frontend/src/router/index.jsx
import { createBrowserRouter } from 'react-router-dom';
import Layout from '../components/Layout';
import Login from '../pages/Login';
import Dashboard from '../pages/Dashboard';
import MusteriYonetimi from '../pages/MusteriYonetimi';
import AracYonetimi from '../pages/AracYonetimi';
import ServisYonetimi from '../pages/ServisYonetimi';
import StokYonetimi from '../pages/StokYonetimi';
import FaturaYonetimi from '../pages/FaturaYonetimi';
import KasaYonetimi from '../pages/KasaYonetimi';
import TeslimYonetimi from '../pages/TeslimYonetimi';

const router = createBrowserRouter([
  {
    path: '/login',
    element: <Login />
  },
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        path: '/',
        element: <Dashboard />
      },
      {
        path: '/musteriler',
        element: <MusteriYonetimi />
      },
      {
        path: '/araclar',
        element: <AracYonetimi />
      },
      {
        path: '/servis',
        element: <ServisYonetimi />
      },
      {
        path: '/stok',
        element: <StokYonetimi />
      },
      {
        path: '/faturalar',
        element: <FaturaYonetimi />
      },
      {
        path: '/kasa',
        element: <KasaYonetimi />
      },
      {
        path: '/teslim',
        element: <TeslimYonetimi />
      }
    ]
  }
]);

export default router;
