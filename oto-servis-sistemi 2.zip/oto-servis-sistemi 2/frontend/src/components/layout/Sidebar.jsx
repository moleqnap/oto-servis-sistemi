// /oto-servis-sistemi/frontend/src/components/layout/Sidebar.jsx
import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const Sidebar = () => {
  const { user } = useAuth();

  const menuItems = [
    { path: '/', label: 'Dashboard', icon: '📊' },
    { path: '/musteriler', label: 'Müşteriler', icon: '👥' },
    { path: '/araclar', label: 'Araçlar', icon: '🚗' },
    { path: '/servis', label: 'Servis', icon: '🔧' },
    { path: '/stok', label: 'Stok', icon: '📦' },
    { path: '/faturalar', label: 'Faturalar', icon: '📄' },
    { path: '/kasa', label: 'Kasa', icon: '💰' },
    { path: '/teslim', label: 'Teslim', icon: '🔑' },
  ];

  return (
    <div className="bg-secondary text-white w-64 min-h-screen p-4">
      <div className="space-y-4">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-700 ${
                isActive ? 'bg-gray-700' : ''
              }`
            }
          >
            <span>{item.icon}</span>
            <span>{item.label}</span>
          </NavLink>
        ))}
      </div>
    </div>
  );
};

export default Sidebar;
